/*
Alexander Gill

CS3505

Assignment 3: Trie

September 24, 2021

These are the implementations for the public functions and helper functions in the Trie Class.
*/

#include <string>
#include <vector>
#include "Trie.h"
using namespace std;

//Standard Constructor Definition
Trie::Trie(){
	isWord = false;
}

//Copy Constructor Definition, all the internals are passed over without the actual pointers of the original
Trie::Trie(const Trie& other){
	isWord = other.isWord;
	//Running over all branches and copying the ones that are not nullptr
	for(int i = 0; i < 26; i++){
		if(other.Branches[i]){
			Branches[i] = new Trie(*(other.Branches[i]));
		}
	}
}

//Assignment Operator, like the copy constructor, but pointers are passed over so the new object is the same as the old
Trie& Trie::operator=(Trie other){
	for(int i = 0; i<26;i++){
		swap(Branches[i],other.Branches[i]);
	}
	swap(isWord,other.isWord);
	return *this;
}

// Destructor for Trie, Deletes the pointers to the other nodes, everything else will be removed automatically by compiler
Trie::~Trie(){
	for(int i = 0; i < 26; i++){
		if(Branches[i]){
			delete Branches[i];
		}
	}
}

//Helper function that converts a character to an index for the branches,
//and takes the first character off a word for recursion
void Trie::recPrep(int &index,string &word){
	//This will convert from a character to an index for the next branch
	index = int(word[0]) - 97;
	word = word.erase(0,1);
}

//Another helper function that returns true when a word is length 0.
//This means a word has been placed in the Trie and the isword flag should be set true.
bool Trie::isWordEnd(string word){
	return (0 == word.length());
}

/*last helper function, this one is for allWordsStartingWithPrefix
It checks if a branch exists off an index, and if it does, it recurses into 
that branch and returns with all string that fall below that index in the Trie
Then, adding the letter associated to that index to each string recurses the string back, to where
full words are formed when the root is reached*/
vector<string> Trie::AddLetter(vector<string> newwordList,string add_char, int index, string prefix){
	vector<string> oldwordList;
	string temp;
	//Checking if branch exists, if not, do nothing
	if (Branches[index]){
		//recursing down that branch to find all options, and return them in a vector
		oldwordList = Branches[index] -> allWordsStartingWithPrefix(prefix);
		//Removing strings one by one and adding the character associated with the index to each new string
		while(!oldwordList.empty()){
			temp = oldwordList.back();
			temp.insert(0,add_char);
			//adding the modified strings to the "master" vector
			newwordList.push_back(temp);
			oldwordList.pop_back();
		}
		//If the object we just iterated into is the end of a word, it needs to be added to the vector as well.
		if (Branches[index]->isWord){
			newwordList.push_back(add_char);
		}
	}
	return newwordList;
}

//adds a word recursively to the Trie
void Trie::addAWord(string word){
	int index;
	// if this is the last character, the isWord flag must be on for the node.
	if (isWordEnd(word)){
		isWord = true;
		return;
	}
	//Preparing the word and the index value for recursion
	recPrep(index, word);
	//If the branch object doesn't exist yet, create a new node and assign it's address to the pointer
	if (!Branches[index]){
		Trie* newNode = new Trie;
		Branches[index] = newNode;
	}
	//recurse into the appropriate node, until the word ends.
	Branches[index] -> addAWord(word);
}

//Checks if a word exists in the Trie
bool Trie::isAWord(string word){
	int index;
	bool isWordResult;
	//If the word being tested has ended, return the isWord flag of the current object
	if (isWordEnd(word)){
		isWordResult = isWord;
		return isWordResult;
	}
	// Prep the word for recursion
	recPrep(index, word);
	// If the branch doesn't exist, then the word isn't in the trie
	if(!Branches[index]){
		return false;
	}
	//Recurse until the word is finished and the flag is found.
	isWordResult = Branches[index] -> isAWord(word);
	return isWordResult;
}


//Finds all words in the Trie beginning with a prefix
vector<string> Trie::allWordsStartingWithPrefix(string prefix){
	vector<string> oldwordList;
	vector<string> newwordList;
	string add_char;
	int index;
	//if the current object in the Trie is below the prefix, we need to check every branch of the object,
	//because each branch is a letter under the prefix.
	if(isWordEnd(prefix)){
		//Checking every branch for existing objects and getting their vectors using AddLetter
		for (int i = 0; i < 26; i++){
			add_char = char (i + 97);
			newwordList = AddLetter(newwordList,add_char,i,prefix);
		}
	}
	// ELSE we are still travelling down through the prefix, so the next branch is the next letter in prefix.
	// same process as isAWord
	else{
		add_char = prefix[0];
		recPrep(index,prefix);
		newwordList = AddLetter(newwordList,add_char,index,prefix);
	}
	return newwordList;
}