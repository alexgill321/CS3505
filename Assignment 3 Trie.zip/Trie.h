/*
Alexander Gill

CS3505

Assignment 3: Trie

September 24, 2021

These are the definitions for the entire Trie class, including all private and public members.
*/

#ifndef TRIE_H
#define TRI_H

#include <string>
#include <vector>
using namespace std;

class Trie {
	private:
		Trie* Branches[26] = {};
		bool isWord;
		bool isWordEnd(string word);
		void recPrep(int &index, string& word);
		vector<string> AddLetter(vector<string> oldwordList, string add_char, int index, string prefix);
	public:
		Trie();
		~Trie();
		Trie(const Trie& other);
		Trie& operator=(Trie other);
		void addAWord(string word);
		bool isAWord(string word);
		vector<string> allWordsStartingWithPrefix(string prefix);
};

#endif