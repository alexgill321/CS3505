/*
Alexander Gill

CS3505

Assignment 3: Trie

September 24, 2021

This is the main function for testing the implementations of the Trie Class
*/

#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include "Trie.h"
using namespace std;

int main(int argc, char *argv[]){
	// Declaring the root and another Trie object which will be used to 
	Trie root;
	Trie root2;
	string line;

	// Getting the files input when running the executable
	ifstream wordFile(argv[1]);
	ifstream findFile(argv[2]);

	//Declaring the vector to hold any results from the prefix function
	vector<string> wordList;

	//Adding all words from the first dictionary
	if (wordFile.is_open()){
		while(getline(wordFile,line)){
			root.addAWord(line);
		}
		wordFile.close();
	}
	//Testing Assignment Operator, root2 should be root now, and all the pointers should work
	root2 = root;
	//Testing the copy constructor
	Trie copy_root = root;

	//Sending all words from the second text file to the Trie to determine if they are contained there
	if (findFile.is_open()){
		while(getline(findFile,line)){
			//Testing root2 to ensure it is equal to root
			if(root2.isAWord(line)){
				cout <<line << " is found" <<endl;
			}
			// If word is not found, test it as a prefix and return all the results
			else{
				cout << line << " is not found, did you mean:" << endl;
				wordList = root2.allWordsStartingWithPrefix(line);
				//If the prefix finder returns an empty vector, then there were no matches for words
				//with that prefix.
				if(wordList.empty()){
					cout << "   no alternatives found" << endl;
				}
				// Outputting all the prefixes found, if any
				for (string word: wordList){
					cout << "   " << word << endl;
				}
			}
		}
	}
}